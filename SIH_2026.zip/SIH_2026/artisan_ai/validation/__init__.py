"""artisan_ai.validation"""
